import React from 'react';


export const Profile = (props) => {
    const [user, setUser] = React.useState({
      email: "",
      age: null,
      name: "",
      _id: ""
    });

    const getUser = async() => {
      const res = await fetch('https://api-nodejs-todolist.herokuapp.com/user/me', {
          method: 'GET',
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + await sessionStorage.getItem('apiKey')
          },
        });

      setUser({...await res.json()})
    }
    const userLogout = async () => {
      try{
        const res = await fetch('https://api-nodejs-todolist.herokuapp.com/user/logout', {
          method: 'POST',
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + await sessionStorage.getItem('apiKey')
          },
        });
        if(res.status !== 200){
          alert(await res.text())
        }else{
            const bodyStream = (await res.json());
            await sessionStorage.removeItem('apiKey');
            props.changePage("Login");
        }
      }catch(ex){
        alert(ex.getMessage());
      }
        
    }

    React.useEffect(() => {
      getUser();
    }, []); 
    return <div style={{display: 'flex', flexDirection: 'column'}}>
    <label htmlFor="email">Email</label>
    <input value={user.email} disabled id="email" type="email" />
    <label htmlFor="id">ID</label>
    <input disabled value={user._id} id="id" type="text" />
    <label htmlFor="name">Nome</label>
    <input disabled value={user.name} id="name" type="text"/>
    <label htmlFor="age">Età</label>
    <input disabled value={user.age} id="age" type="number"/>
    <button type="button" onClick={userLogout} style={{marginTop: 12}}>Logout</button>
  </div>
}