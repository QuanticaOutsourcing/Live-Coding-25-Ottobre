import React from 'react';


export const Login = (props) => {
    const [email, setEmail] = React.useState("");
    const [password, setPassword] = React.useState("");

    const userLogin = async () => {
        const res = await fetch('https://api-nodejs-todolist.herokuapp.com/user/login', {
          method: 'POST',
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            email: email,
            password: password
          }),
        });
        if(res.status === 200){
            const bodyStream = (await res.json());
            await sessionStorage.setItem('apiKey', bodyStream.token);
            console.log('Il tuo token è: ', bodyStream.token);
            props.changePage("Profile");
        }else{
            alert(await res.text());
        }
    }

    return <div style={{display: 'flex', flexDirection: 'column'}}>
    <label htmlFor="email">Email</label>
    <input id="email" type="email" onChange={(e) => setEmail(e.currentTarget.value)} />
    <label htmlFor="password">Password</label>
    <input id="password" type="password" onChange={(e) => setPassword(e.currentTarget.value)} />
    <button type="button" onClick={userLogin} style={{marginTop: 12}}>Accedi</button>
    <a href="#" onClick={() => props.changePage("Register")}>Ti vuoi registrare?</a>
  </div>
}