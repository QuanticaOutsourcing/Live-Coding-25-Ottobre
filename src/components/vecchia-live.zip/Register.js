import React from 'react';


export const Register = (props) => {
    const [user, setUser] = React.useState({
      email: "",
      password: "",
      age: null,
      name: ""
    });
    const setUserVariable = (value, key) => {
      let _user = user;
      _user[key] = value;
      setUser({..._user});
    };
    const userSubscribe = async () => {
      try{
        const res = await fetch('https://api-nodejs-todolist.herokuapp.com/user/register', {
          method: 'POST',
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify(user),
        });

        if(res.status !== 201){
          alert(await res.text())
        }else{
            const bodyStream = await res.json();
            await sessionStorage.setItem('apiKey', bodyStream.token);
            console.log('Il tuo token è: ', bodyStream.token);
            props.changePage("Profile");
        }
      }catch(ex){
        alert(ex.getMessage());
      }
        
    }

    return <div style={{display: 'flex', flexDirection: 'column'}}>
    <label htmlFor="email">Email</label>
    <input id="email" type="email" onChange={(e) => setUserVariable(e.currentTarget.value, 'email')} />
    <label htmlFor="password">Password</label>
    <input id="password" type="password" onChange={(e) => setUserVariable(e.currentTarget.value, 'password')} />
    <label htmlFor="name">Nome</label>
    <input id="name" type="text" onChange={(e) => setUserVariable(e.currentTarget.value, 'name')} />
    <label htmlFor="age">Età</label>
    <input id="age" type="number" onChange={(e) => setUserVariable(e.currentTarget.value, 'age')} />
    <button type="button" onClick={userSubscribe} style={{marginTop: 12}}>Registrati</button>
    <a href="#" onClick={() => props.changePage("Login")}>Vuoi accedere?</a>
  </div>
}